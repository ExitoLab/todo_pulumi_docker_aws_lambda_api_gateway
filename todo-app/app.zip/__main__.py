import pulumi
import pulumi_aws as aws
from pulumi_docker import Image, DockerBuild

# Define the Docker image with the correct context path
app_image = Image(
    "my-serverless-app",
    build=DockerBuild(context="lambda_function"),  # Just the folder, not the Dockerfile path
    image_name="my-serverless-app"
)

# Create an IAM Role for the Lambda function
lambda_role = aws.iam.Role("lambdaExecutionRole",
    assume_role_policy="""{
      "Version": "2012-10-17",
      "Statement": [
        {
          "Action": "sts:AssumeRole",
          "Principal": {
            "Service": "lambda.amazonaws.com"
          },
          "Effect": "Allow",
          "Sid": ""
        }
      ]
    }"""
)

# Attach the basic execution policy to the role
lambda_policy_attachment = aws.iam.RolePolicyAttachment("lambdaExecutionPolicy",
    role=lambda_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
)

# Create a Lambda function
lambda_function = aws.lambda_.Function("my-serverless-function",
    role=lambda_role.arn,
    code=pulumi.FileArchive("app/app.zip"),
    handler="app.lambda_handler",
    runtime="python3.9",
    memory_size=128,
    timeout=30,
    environment={
        "DOCKER_IMAGE": app_image.image_name,
    })

# Create an API Gateway REST API
api = aws.apigateway.RestApi("my-api",
    description="My serverless API")

# Create a resource for the API
resource = aws.apigateway.Resource("hello-resource",
    rest_api=api.id,
    parent_id=api.root_resource_id,
    path_part="hello")

# Create a method for the resource
method = aws.apigateway.Method("hello-method",
    rest_api=api.id,
    resource_id=resource.id,
    http_method="GET",
    authorization="NONE")

# Integration of Lambda with API Gateway
integration = aws.apigateway.Integration("hello-integration",
    rest_api=api.id,
    resource_id=resource.id,
    http_method=method.http_method,
    integration_http_method="POST",
    type="AWS_PROXY",
    uri=lambda_function.invoke_arn)

# Deployment of the API
deployment = aws.apigateway.Deployment("api-deployment",
    rest_api=api.id,
    stage_name="dev")

# Export the API endpoint
pulumi.export("url", deployment.invoke_url)
